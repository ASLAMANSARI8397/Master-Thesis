.. End-to-End Machine Learning Pipeline for Distance Estimation and Human-Robot Interaction in Autonomous Systems documentation master file

End-to-End Machine Learning Pipeline for Distance Estimation and Human-Robot Interaction in Autonomous Systems
==============================================================================================================

Add your content using ``reStructuredText`` syntax. See the `reStructuredText <https://www.sphinx-doc.org/en/master/usage/restructuredtext/>`_ documentation for details.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   introduction
   environment_setup
   requirements
   data_preprocessing
   model_training
   rosbag_to_video
   distance_angle_estimation
   evaluation_visualization
   